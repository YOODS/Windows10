#pragma once

#include "mypoint.h"

struct PointChain {
	Point3D *p;
	PointChain *next;
	PointChain(Point3D *a);
	PointChain* add(Point3D *ap);
	int count(void);
	~PointChain(void);
};

struct PCMesh {
	PointChain *c;
	PCMesh(void);
	~PCMesh(void);
	PointChain* add(Point3D* ap);
	int count(void);
	void clean(void);
};
