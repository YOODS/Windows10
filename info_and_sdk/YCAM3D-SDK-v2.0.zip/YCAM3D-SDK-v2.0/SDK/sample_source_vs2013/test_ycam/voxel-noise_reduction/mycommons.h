#pragma once

extern int atox(char *p,int n);
extern void get_minmax(Point3D *dp,int dn, AreaLimits *a);
