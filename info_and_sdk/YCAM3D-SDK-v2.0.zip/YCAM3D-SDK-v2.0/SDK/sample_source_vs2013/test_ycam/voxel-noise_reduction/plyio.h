#pragma once 

extern Point3D *read_ply(char *fname,int *dn);
extern void write_ply(Point3D *dp,int dn,char *outfn,int ascf,int notexf,unsigned char *color);