#pragma once
#include <string>

typedef std::basic_string<TCHAR> tstring;

extern void makeBitmapSpec(BITMAPINFOHEADER *bih, RGBQUAD *col, int width, int height);
extern BOOL dispImageDC(HDC hdc, BYTE *img, int width, int height, BYTE *bmp);
extern BOOL setClientSize(HWND hWnd, int width, int height);
extern void resizeImage(const BYTE *srcd, int sw, int sh, int dw, int dh, BYTE *destd);
extern void onVScroll(HWND hWnd, int mes, int *Vpos);
extern void onHScroll(HWND hWnd, int mes, int *Hpos);
extern void onSize(HWND hWnd, int w, int h, int *Hpos, int *Vpos);

extern bool saveImagePNM(const char *path, BYTE *imgData, int m, int n, int e);
extern bool readImagePNM(LPCTSTR path, BYTE **imgData, int *m = 0, int *n = 0, int *e = 0);
extern bool readImagePNM_LR(LPCTSTR path, BYTE *imgData[], int *m = 0, int *n = 0, int *e = 0);
extern bool savePly(char *path, int num, float *xyz, BYTE *rgb, bool rg = false, int width = -1, int height = -1, int *rg_id = 0);

extern bool execCommand(const char *cmd, bool wait=true);

extern tstring module_dir();
extern tstring module_path(LPCTSTR file);

BOOL setRegValue(HKEY root, char *path, char *key, DWORD dwNewValue);
DWORD getRegValue(HKEY root, char *path, char *key, DWORD dwDefault);
BOOL setRegText(HKEY root, char *path, char *key, char *szBuffer);
BOOL getRegText(HKEY root, char *path, char *key, char *szBuffer, LPDWORD dwBufferSize, char *szDefault);
int lAddr(char *p);
