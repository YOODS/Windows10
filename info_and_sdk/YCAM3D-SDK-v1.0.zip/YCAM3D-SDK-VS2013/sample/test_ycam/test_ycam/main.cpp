#include <Windows.h>
#include <tchar.h>
#include <stdio.h>
#include <conio.h>
#include <process.h>
#include <deque>
#include <vector>
#include "Elapse.h"
#include "IYCam3D.h"
#include "IDecPhsft.h"
#include "IDecSgbm.h"
#include "function.h"
#include "voxel-noise_reduction\noise_reduct.h"
#include "voxel-noise_reduction\plyio.h"
#include "ComIpc.h"
#include "Event.h"
#include "WaitTimer.h"
#include "TimerThread.h"

using namespace std;

struct CS {
	CRITICAL_SECTION *cs_;
	CS(CRITICAL_SECTION *cs) :cs_(cs) { EnterCriticalSection(cs); }
	~CS() { LeaveCriticalSection(cs_); }
};

#define INITIAL_EXPOSURE_TIME 16800	//�����I������
#define INITIAL_GAIN_VALUE 0		//�����Q�C��

#define INPUT_EVENT "INPUT_EVENT"
static HANDLE hEventInput = INVALID_HANDLE_VALUE;
static HANDLE hThreadGets = INVALID_HANDLE_VALUE;
static UINT WINAPI gets_loop(void *arg);

static int CALLBACK cb_recvimg(int camno, int index, int width, int height, void *mem);
static void CALLBACK timerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime);
static BYTE *img[] = { 0, 0 };
static BYTE *camera_img[] = { 0, 0 };
static BYTE *img_small[] = { 0, 0 };
static IYCam3D *camera = 0;
static int calib_no = -1;
static UINT_PTR timer_id=0;
//
#define RECT_EVENT "RECT_EVENT"
static HANDLE hEventRect = INVALID_HANDLE_VALUE;
typedef struct{
	int camno, index;
} RectKey;
typedef std::deque<RectKey> RectQue;
RectQue rectq;
CRITICAL_SECTION cs_window, cs_camera;
static HMODULE loadYcamLibrary(pCreateIYCam3DInstance *pcreate_camera);
static HANDLE hThreadRect = INVALID_HANDLE_VALUE;
//
#define TIMER_INTERVAL 500 //ms
#define TIMER_ID 1000
//Live
static bool live_end = false;
static BOOL live_flg = FALSE;
static HANDLE hThreadLive = INVALID_HANDLE_VALUE;
static UINT WINAPI live_loop(void *arg);
static void stopLive();

static bool save_flg = false;	//�B�e�摜�ۑ��t���O
static BOOL rg_flg = FALSE;	// �����W�O���b�h�ۑ��t���O
static bool stdv_flg = false;	//���������P�x�W���΍��v�Z�t���O

std::vector<float> stdv[2];

//#define DUMMY

#ifdef DUMMY
#define IMGWIDTH 1280
#define IMGHEIGHT 1024
#else
#define IMGWIDTH (camera->imageSize().cx)
#define IMGHEIGHT (camera->imageSize().cy)
#endif
#define IMGSIZE (IMGWIDTH*IMGHEIGHT)

////#Window�֘A
//#define WWIDTH_INIT 640
//#define WHEIGHT_INIT 480
#define WWIDTH_INIT (640<IMGWIDTH ? (IMGWIDTH>>1) : IMGWIDTH)
#define WHEIGHT_INIT (640<IMGWIDTH ? (IMGHEIGHT>>1) : IMGHEIGHT)
int Hpos[] = { 0, 0 };
int Vpos[] = { 0, 0 };
float scales[] = { 1.0f, 1.0f };
//
static HWND hWnd[] = {0, 0};
static ATOM atom = 0;
static HANDLE hThread = INVALID_HANDLE_VALUE;
static BYTE *bmp[] = { 0, 0 };
//
static BOOL create_window(int camno);
static UINT WINAPI window_loop(void *arg);
////#

////# �ʑ��V�t�g�֘A
static IDecPhsft *phsft = 0;		//�ʑ��V�t�g�v�Z���C�u����
////# �X�e���I���֊֘A
static IDecSgbm *sgbm = 0;			//�X�e���I���֌v�Z���C�u����

typedef std::vector<POINTS> CircleContour;
static CircleContour circles[2];
#define CALIB_DIR "..\\calib\\"
#define CAPT_DIR "..\\capt\\"

////�ʐM�p(�s�b�L���O�p�Ȃ̂ŃT���v���\�[�X�Ƃ��Ă͊֌W�Ȃ�)
#define PICKING
#define CAPT_DONE_EVENT "CAPT_DONE_EVENT"		//to picking process
#define PHSFT_DONE_EVENT "PHSFT_DONE_EVENT"		//to picking process
static BOOL create_pickwindow();

static char key[64];
static int recv_bit[CAMNUM] = { 0 };

#define REG_KEY "Software\\YOODS\\test_ycam"

static Elapse e;     // �B�e�������Ԍv�� (cb_recvimg()�����z)
/* For IPC */
static HANDLE hEventInputIpc = INVALID_HANDLE_VALUE;
struct cb_func : public IpcCallbackFunc{
	void operator()(CONST USHORT id, CONST CHAR cmdType, LPCSTR cmdName, CONST CHAR dataType,
		LPBOOL pOK, PVAR pVar, LPINT pSize);
};
static IIpcServer *ipc = 0;
static int init_status = 0;	//������: 0=�O, 1=OK, 2=NG
static PVAR ipcVar = new VAR;
static LPBOOL ipcOK = new BOOL;
static Event *eventIpc = 0;
static INT ypj_addr = 0;
static bool one_shot = false;	//phsft,sgbm�ŎB�閇�����Ⴄ�̂� true=sgbm
#pragma pack(1)
typedef struct{
	BOOL bLive;
	INT triggerMode;
	BOOL bProjCon;
} SHMEM,*PSHMEM;
#pragma pack()
PSHMEM shmem = 0;
/* For Ipc*/

/* For commercial projector*/
static IIpcClient *ipc_proj = 0;
static bool proj_conn = false;

#define COMPROJ 	if(!proj_conn){ \
						if (proj_conn = ipc_proj->open("YCAM_PROJ")){ \
							printf("projector connected.\n"); \
						} \
					};

class ProjectorThread : public TimerThread {
	int frames = 13;
	int frame;
	WaitTimer wait;
public:
	ProjectorThread():delay_ms(0){}
	int delay_ms;
protected:
	void pre_start(){ frame = 0; }
	bool run(){
		ipc_proj->setInt("C", frame, FALSE);
		wait.sleep(delay_ms * 1000);
		if (!camera->capture())return false;
		return ++frame < frames;
	}
} com_proj;
/* For commercial projector*/

AreaLimits varea;
Delete_Noise *mesh = NULL;

void noise_reduction(int *num, float *xyz, BYTE *rgb) {
	if (!mesh) return;
	Point *dp = new Point[*num];
	float *bxyz = xyz;
	BYTE  *brgb = rgb;

	for (int i = 0; i < *num; ++i) {
		dp[i] = { xyz[0], xyz[1], xyz[2], rgb[0], rgb[1], rgb[2], 255 };
		xyz += 3;
		rgb += 3;
	}
	mesh->set_points(dp, *num);
	mesh->work(NULL);

	xyz = bxyz;
	rgb = brgb;
	*num = mesh->get_vcount();
	Point *rp = mesh->get_vpoints();
	for (int i = 0; i< *num; i++) {
		xyz[i * 3 + 0] = rp[i].x;
		xyz[i * 3 + 1] = rp[i].y;
		xyz[i * 3 + 2] = rp[i].z;
		rgb[i * 3 + 0] = rp[i].r;
		rgb[i * 3 + 1] = rp[i].g;
		rgb[i * 3 + 2] = rp[i].b;
//		printf("%d:%f %f %f\n", i, rp[i].x, rp[i].y, rp[i].z);
	}
	mesh->clearMesh();
	delete[] dp;
}


#define TEST_YCAM_TITLE "test_ycam.exe"

int _tmain(int argc, _TCHAR *argv[])
{
	SetConsoleTitle(TEST_YCAM_TITLE);
	{
		RECT rw, rc;
		SystemParametersInfo(SPI_GETWORKAREA, 0, &rw, 0);
		HWND hwnd=FindWindow(0, TEST_YCAM_TITLE);
		GetWindowRect(hwnd, &rc);
		SetWindowPos(hwnd, hwnd, 0, rw.bottom - (rc.bottom - rc.top), 0, 0, SWP_NOSIZE | SWP_NOZORDER);
	}
	hEventRect = CreateEvent(NULL, TRUE, FALSE, RECT_EVENT);	//�蓮���Z�b�g,��V�O�i��
	InitializeCriticalSection(&cs_window);
	InitializeCriticalSection(&cs_camera);
	hEventInput = CreateEvent(NULL, TRUE, FALSE, INPUT_EVENT);
	hEventInputIpc = CreateEvent(NULL, TRUE, FALSE, NULL);

	cb_func cb_server;
	CComIpc mgr;
	if (mgr.loadLib()){
		ipc = mgr.createIpcServer();
		//ipc->setLog(IpcLogMode_Console);
		if (ipc->open("YCAM_IPC", 5)){
			eventIpc = new Event;
			ipc->addCallbackIpc(&cb_server);
			shmem = (PSHMEM)ipc->createShMem("YCAM_MEM", 4096);
			shmem->bLive = FALSE;
			shmem->bProjCon = FALSE;
		}
		//
		ipc_proj = mgr.createIpcClient();
		COMPROJ
	}

	// �m�C�Y����
	FILE *fp;
	fopen_s(&fp,"noise_reduction.txt","r");
	if (fp) {
		fscanf_s(fp, "%f%f", &varea.xmin, &varea.xmax);
		fscanf_s(fp, "%f%f", &varea.ymin, &varea.ymax);
		fscanf_s(fp, "%f%f", &varea.zmin, &varea.zmax);
		float rd, msize;
		int dir;
		fscanf_s(fp, "%f%f%d", &rd, &msize, &dir);
		fclose(fp);
		mesh = new Delete_Noise;
		printf("allocating mesh....\n");
		mesh->mk_mesh(&varea, msize);
		mesh->set_params(rd, dir);
		printf("done\n");
	}

	//CAMERA���擾
	fopen_s(&fp,"camtype.txt", "r");
	int pixels, colorf;
	if (fp) {
		fscanf_s(fp, "%d%d", &pixels, &colorf);
		fclose(fp);
	}
	else {
		pixels = 130; colorf = 0;
	}

	//YCAM3D���C�u���������[�h
	pCreateIYCam3DInstance create_camera;
	HMODULE hCamera = loadYcamLibrary(&create_camera);
	if (hCamera == NULL) {
		fprintf(stderr, "error: LoadLibrary - YdsCamXXXX\n");
		return 1;
	}
	//�C���X�^���X���쐬
	camera = create_camera();
	camera->setLog(CamLogMode_Console | CamLogMode_File,"log_camera.txt");
	int ok=camera->open(pixels,colorf);
	printf("Left:%s,Right:%s\n", ok & 1 ? "OK" : "NG", ok & 2 ? "OK" : "NG");
	char ypjaddr[32];
	DWORD dwsize = sizeof(ypjaddr);
	getRegText(HKEY_CURRENT_USER, REG_KEY, "YPJPort", ypjaddr, &dwsize, "192.168.222.10");
	int ypjok;
	if (strchr(ypjaddr, '.')) {
		ypj_addr = lAddr(ypjaddr);
		ypjok = camera->openComPort(ypj_addr);
	}
	else {
		ypjok = camera->openComPort(ypjaddr[0]-'0');
	}
	if (shmem)shmem->bProjCon = ypjok ? TRUE:FALSE;
	printf("YPJ Port open %s(%s).\n",ypjok ? "OK":"Error",ypjaddr);

	if (ok){
		printf("image size=%d,%d\n", IMGWIDTH, IMGHEIGHT);
		int ini_et = getRegValue(HKEY_CURRENT_USER, REG_KEY, "ExposureTime", INITIAL_EXPOSURE_TIME);
		int ini_gn = getRegValue(HKEY_CURRENT_USER, REG_KEY, "Gain", INITIAL_GAIN_VALUE);
		int ini_gnx = getRegValue(HKEY_CURRENT_USER, REG_KEY, "Gainx", INITIAL_GAIN_VALUE);
		printf("set: exposure_time=%d,gain=%d,gainx=%d\n", ini_et, ini_gn, ini_gnx);
		for (int i = 0; i < CAMNUM; ++i){
			img[i] = new BYTE[IMGSIZE];
			ZeroMemory(img[i], IMGSIZE);
			img_small[i] = new BYTE[IMGSIZE];
			bmp[i] = new BYTE[IMGSIZE + IMGHEIGHT * 3];	//�\���p�F�s���Ƃ�padding���l��
			camera->addCallbackRecvImage(i, cb_recvimg, img[i]);
			if ((i + 1) & ok){
				camera->setExposureTime(i, ini_et);
				camera->setGain(i, ini_gn);
				camera->setGainx(i, ini_gnx);
			}
		}
	}
#ifdef DUMMY
	for (int i = 0; i < CAMNUM; ++i){
		img[i] = new BYTE[IMGSIZE];
		img_small[i] = new BYTE[IMGSIZE];
		bmp[i] = new BYTE[IMGSIZE + IMGHEIGHT * 3];	//�s���Ƃ�padding���l��
	}
	readImagePNM_LR("../../calib00.pgm", img);
#endif

	hThread = (HANDLE)_beginthreadex(NULL, 0, window_loop, NULL, 0, NULL);

	//�ʑ��V�t�g���C�u����������
	HMODULE hPhsft = LoadLibrary("YdsDecPhsft.dll");
	if (hPhsft == NULL) {
		fprintf(stderr, "error: LoadLibrary - YdsDecPhsft\n");
	}
	else{
		pCreateIDecPhsftInstance create_phsft = (pCreateIDecPhsftInstance)GetProcAddress(hPhsft, "CreateIDecPhsftInstance");
		if (create_phsft == NULL) {
			fprintf(stderr, "error: GetProcAddress\n");
		}
		else{
			phsft = create_phsft();
		}
	}
	if (phsft){
		//�ʑ��V�t�g�̃��O�o�͐�
		phsft->setLog(PhsftLogMode_File | PhsftLogMode_Console, "log_phsft.txt");
		bool ok = false;
		for (;;){
			if (!phsft->init("PHSFT.ini")) break;
			for (int i = 0; i < 2; ++i){
				camera_img[i] = new BYTE[IMGSIZE*phsft->ptn_num()];
			}
			phsft->setCameraImages(camera_img);
			//���N�e�B�t�@�C�p�����[�^�t�@�C��������f�B���N�g�����w��
			if (!phsft->setRectParam(CALIB_DIR)){}// break;
			//HMAT�p�����[�^�t�@�C��������f�B���N�g�����w��
			if (!phsft->setHmat(CALIB_DIR)){}// break;
			ok = true;
			break;
		}
		if (!ok){
			fprintf(stderr, "error: initialize phaseshift library\n");
			phsft->destroy();
			phsft = 0;
			FreeLibrary(hPhsft);
		}
	}
	//���փ��C�u����������
	HMODULE hSgbm = LoadLibrary("YdsDecSgbm.dll");
	if (hSgbm == NULL) {
		//fprintf(stderr, "error: LoadLibrary - YdsDecSgbm\n");
	}
	else{
		pCreateIDecSgbmInstance create_sgbm = (pCreateIDecSgbmInstance)GetProcAddress(hSgbm, "CreateIDecSgbmInstance");
		if (create_sgbm == NULL) {
			fprintf(stderr, "error: GetProcAddress\n");
		}
		else{
			sgbm = create_sgbm();
		}
	}
	if (sgbm){
		//�X�e���I���ւ̃��O�o�͐�
		sgbm->setLog(SgbmLogMode_File | SgbmLogMode_Console, "log_sgbm.txt");
		bool ok = false;
		for (;;){
			if (!sgbm->init("SGBM.ini")) break;
			for (int i = 0; i < 2; ++i) {
				if (!camera_img[i]) camera_img[i] = new BYTE[IMGSIZE];
			}
			sgbm->setCameraImages(camera_img);
			if (!sgbm->setRectParam(CALIB_DIR)){}// break;
			if (!sgbm->setHmat(CALIB_DIR)){}// break;
			ok = true;
			break;
		}
		if (!ok){
			fprintf(stderr, "error: initialize stereosgbm library\n");
			sgbm->destroy();
			sgbm = 0;
			FreeLibrary(hSgbm);
		}
	}
	camera->setTriggerMode(TrigMode_SW);
	if (shmem) shmem->triggerMode = TrigMode_SW;
	hThreadLive = (HANDLE)_beginthreadex(NULL, 0, live_loop, NULL, 0, NULL);

	Sleep(100);
	stopLive();
	puts("<HW trigger>");
	camera->setTriggerMode(TrigMode_HW);
	if(shmem) shmem->triggerMode = TrigMode_HW;

#ifdef PICKING
	hThreadGets = (HANDLE)_beginthreadex(NULL, 0, gets_loop, key, 0, NULL);
	if (ok && phsft) init_status = 1;	//OK
	else init_status = 2;	//ERR
	if (ipc)ipc->trigger(_T("INIT"), IpcDataType_Int, init_status == 1 ? 1 : 0);

	HANDLE hEvents[2];
	DWORD  dwEventNo;
	hEvents[0] = hEventInput;
	hEvents[1] = hEventInputIpc;
//	for (bool loop = true; loop && printf("command: ") && WAIT_OBJECT_0 == WaitForSingleObject(hEventInput, INFINITE);){
	for (bool loop = true; loop && printf("command: ") && 0 <= (dwEventNo=(WaitForMultipleObjects(2, hEvents, FALSE, INFINITE) - WAIT_OBJECT_0));){
#else
	for (bool loop = true; loop && printf("command: ") && fgets(key, sizeof(key), stdin);){
#endif
		bool raise_event = true;
		ResetEvent(hEventInput);
		ResetEvent(hEventInputIpc);
		e.reset();
		for (char *c = key; *c; ++c) *c = toupper(*c);
		switch (key[0])
		{
		case 'Q':	//�I��
			stopLive();
			loop = false;
			break;
		case 'U':
			stdv_flg = (key[1] == '\n' ? 0 : key[1] - '0') ? true : false;
			if (stdv_flg) for (int i = 0; i < 2;++i) stdv[i].resize(IMGHEIGHT, 0);
			break;
		case 'Z':	//�摜�ۑ��FZ[01]
			save_flg = (key[1] == '\n' ? 0 : key[1] - '0') ? true : false;
			break;
		case 'K':
			execCommand(module_path("cmd_calib.cmd").c_str(), true);
		case 'J':
			//�L�����u�f�[�^�̃����[�h
			if (phsft){
				phsft->setRectParam(CALIB_DIR);
				phsft->setHmat(CALIB_DIR);
			}
			if (sgbm){
				sgbm->setRectParam(CALIB_DIR);
				sgbm->setHmat(CALIB_DIR);
			}
			puts("<Calibration Result Reloaded>");
			break;
		case 'A':{	//�L�����u���[�V�����摜�m�F
			const int no = atoi(&key[1]);
			char path[MAX_PATH];
			sprintf_s(path, sizeof(path), "%scalib%02d.pgm", CALIB_DIR, no);
			if (ok && readImagePNM_LR(path, img)){
				//�L�����u���[�V�����m�F�p�~�֊s�t�@�C����ǂ�
				for (int j = no * 2; j < (no + 1) * 2; ++j){
					CircleContour &c = circles[j - no * 2];
					c.clear();
					sprintf_s(path, sizeof(path), "%scircle%02d.bin", CALIB_DIR, j);
					FILE *fp;
					errno_t err = fopen_s(&fp, path, "rb");
					if (!err){
						POINTS p;
						while (fread((void*)&p, sizeof(POINTS), 1, fp)){
							c.push_back(p);
						}
						fclose(fp);
					}
					else printf("cannot open: %s\n", path);
				}
				for (int i = 0; i < CAMNUM; ++i){
					InvalidateRect(hWnd[i], NULL, TRUE);
				}
			}
			else {
				*ipcOK = FALSE;
				printf("cannot open: %s\n", path);
			}
			}break;
			///////////////
		case 'R':{
			rg_flg = (!rg_flg);
			ipcVar->ival = (int)rg_flg;
			printf("<range grid:%s>\n", rg_flg ? "ON" : "OFF");
			// ����� ipcOK = TRUE�A�߂�l��GUI�̃`�F�b�N�{�b�N�X�ɔ��f�B
			}	break;
		case 'E':{	//�I������:Ennnn
			if (key[1] == '\n'){
				printf("exposure time=%d,%d\n", ipcVar->ival = camera->exposureTime(0), camera->exposureTime(1));
			}
			else{
				const int e = atoi(&key[1]);
				printf("<exposure time:%d>\n", e);
				CS cs(&cs_camera);
				*ipcOK = camera->setExposureTime(0, e);
				camera->setExposureTime(1, e);
				setRegValue(HKEY_CURRENT_USER, REG_KEY, "ExposureTime", e);
			}
			} break;
		case 'G':{	//�Q�C���FGnnnn
			bool ex = (key[1] == 'X');	//'X'=�g���Q�C��
			char *k = ex ? &key[1] : &key[0];
			if (k[1] == '\n'){
				if (ex) printf("gainx=%d,%d\n", ipcVar->ival = camera->gainx(0), camera->gainx(1));
				else printf("gain=%d,%d\n", ipcVar->ival = camera->gain(0), camera->gain(1));
			}
			else{
				const int g = atoi(&k[1]);
				printf("<gain%s:%d>\n", ex ? "x":"", g);
				CS cs(&cs_camera);
				if (ex){
					*ipcOK = camera->setGainx(0, g);
					camera->setGainx(1, g);
					setRegValue(HKEY_CURRENT_USER, REG_KEY, "Gainx", g);
				}
				else{
					*ipcOK = camera->setGain(0, g);
					camera->setGain(1, g);
					setRegValue(HKEY_CURRENT_USER, REG_KEY, "Gain", g);
				}
			}
			} break;
		case 'C':	//�B�e
			calib_no = (key[1] == '\n' ? -1:atoi(&key[1]));
			if (0 <= calib_no)printf("<capture:%d>\n", calib_no);
			else printf("<capture>\n");
			stopLive();
			//if (camera->triggerMode() == TrigMode_HW)
			//	camera->trigger(DlpModeCapture);
			//else
			*ipcOK = camera->capture();
			if (0<=calib_no) raise_event = false;	//�L�����u�̏ꍇ�̓t�@�C���쐬��ɃC�x���g���グ��
			break;
		case 'D':	//�B�eHW
			calib_no = (key[1] == '\n' ? -1 : atoi(&key[1]));
			printf("<hw capture:%d>\n", calib_no);
			stopLive();
			camera->setTriggerMode(TrigMode_HW);
			if (shmem) shmem->triggerMode = TrigMode_HW;
			camera->trigger(DlpModeCapture);
			break;
		case 'S':	//�\�t�g�E�F�A�g���K���[�h
			puts("<SW trigger>");
			*ipcOK = camera->setTriggerMode(TrigMode_SW);
			if (shmem) shmem->triggerMode = TrigMode_SW;
			break;
		case 'H':	//�n�[�h�E�F�A�g���K���[�h
			puts("<HW trigger>");
			stopLive();
			*ipcOK = camera->setTriggerMode(TrigMode_HW);
			if (shmem) shmem->triggerMode = TrigMode_HW;
			break;
		case 'T':{	//�X�g���{����T[012]
			const int option = key[1] - '0';
			if (option < 0 || 2 < option){
				printf("invalid option:%d\n", option);
				break;
			}
			one_shot = option < 2;
			printf("<trigger:%d>\n", option);
			camera->trigger((DlpMode)option);	//*�������Ă�false�̂Ƃ�������̂�ipcOK�̐ݒ�͂��Ȃ�
			raise_event = false;
			}break;
		case 'P':{	//�V���A���|�[�g�FP[0-9], IP�A�h���X
			if (key[1] == '\n'){
				printf("<YPJPort:close>\n");
				camera->closeComPort();
				if (shmem)shmem->bProjCon = FALSE;
				*ipcOK = TRUE;
			}
			else{
				bool result = false;
				if (strchr(&key[1], '.')){
					ypj_addr = lAddr(&key[1]);
					result = camera->openComPort(ypj_addr);
				}
				else {
					const int port = key[1] - '0';
					printf("<YPJPort:%d>\n", port);
					result = camera->openComPort(port);
				}
				if (result) {
					char *p = strchr(&key[1], '\n');
					if (p) *p = 0;
					setRegText(HKEY_CURRENT_USER, REG_KEY, "YPJPort", &key[1]);
				}
				else *ipcOK = FALSE;
				if (shmem)shmem->bProjCon = result ? TRUE:FALSE;
			}
			}break;
		case 'X':{	//�v���W�F�N�^�[�I������
			if (key[1] == '\n'){
			}
			else{
				const int e = atoi(&key[1]);
				printf("<projector exposure time:%d>\n", e);
				if (camera->setProjectorExposureTime(e)) puts("OK");
				else {
					*ipcOK = FALSE;
					puts("ERR");
				}
			}
			}break;
		case 'L':{	//���C�u�J�n�E�I���FL[01]
			const int option = (key[1] == '\n' ? 0: key[1] - '0');
			if (option){
				puts("<start live>");
				camera->setTriggerMode(TrigMode_SW);
				if (shmem) shmem->triggerMode = TrigMode_SW;
				hThreadLive = (HANDLE)_beginthreadex(NULL, 0, live_loop, NULL, 0, NULL);
			}
			else{
				puts("<stop live>");
				stopLive();
			}
			}break;
		case 'I':{	//I interval[ms] delay[ms]
			COMPROJ
			if (!proj_conn){
				fprintf(stderr, "error: no connection to projector\n");
				break;
			}
			int interval = getRegValue(HKEY_CURRENT_USER, REG_KEY, "CP_IntervalTime", 50);
			int delay = getRegValue(HKEY_CURRENT_USER, REG_KEY, "CP_DelayTime", 10);
			char *ctx,*delim = " ";
			char *c = strtok_s(key, delim, &ctx);
			for (int i = 0; c && i < 2;++i){
				if (c = strtok_s(NULL, delim, &ctx)){
					if (i == 0) interval = atoi(c);
					else if (i == 1) delay = atoi(c);
				}
			}
			setRegValue(HKEY_CURRENT_USER, REG_KEY, "CP_IntervalTime", interval);
			setRegValue(HKEY_CURRENT_USER, REG_KEY, "CP_DelayTime", delay);
			printf("run sequence...interval[%d],delay[%d]\n", interval, delay);
			camera->resetSequence();
			com_proj.delay_ms = delay;
			com_proj.setInterval(interval);
			com_proj.start();
		}break;
		///////////////
		case 'B':{	//�v���W�F�N�^�������x
			if (key[1] == '\n'){
				printf("\nprojector brightness=%d\n",ipcVar->ival=camera->projectorBrightness());
			}
			else{
				const int b = atoi(&key[1]);
				printf("<brightness:%d>\n", b);
				if (camera->setProjectorBrightness(b)) puts("OK");
				else {
					*ipcOK = FALSE;
					puts("ERROR");
				}
			}
			}break;
		case 'O':	//�v���W�F�N�^�����Z�b�g
			puts("<reset projector>");
			*ipcOK = camera->resetProjector();
			break;
		case 'N':{	//�v���W�F�N�^�p�^�[��N[0-3]
			const int ptn = key[1] - '0';
			printf("<projector:%d>\n", ptn);
			if (camera->setProjectorFixedPattern((DlpPattern)ptn))puts("OK");
			else {
				*ipcOK = FALSE; puts("ERR");
			}
			}break;
		///////////////
		case 'V':{	//LOOP
			int n = atoi(&key[1]);
			if (n <= 0) n = 1;
			if (!phsft) n = 0;
			printf("start capture loop [%d count]\n", n);
			for (int i = 0; i < n; i++) {
				float *xyz;
				BYTE *rgb;
				bool dorect = true;
				int *rg_id = 0;         // �����W�O���b�h���_�̃s�N�Z���C���f�b�N�X�z��
				printf("exec %d/%d\n", i + 1, n);
				e.reset();
				camera->trigger((DlpMode)2);
				Sleep(2000);
				int num = phsft->exec(&xyz, &rgb, dorect, &rg_id);
				printf("detected num=%d\n", num);

				if (!rg_flg) {
					// �����W�O���b�h�̂Ƃ��̓m�C�Y�������Ȃ��iPLY�̒��_�̐�������Ȃ��Ȃ�j
					if (!__isnan(varea.xmin)) {
						noise_reduction(&num, xyz, rgb);
						printf("finish noise_del\n");
					}
				}

				char path[MAX_PATH];
				_snprintf_s(path, sizeof(path), _TRUNCATE, "%s%s", CAPT_DIR, "out.ply");
				savePly(path, num, xyz, rgb, rg_flg, IMGWIDTH, IMGHEIGHT, rg_id);
			}
			*ipcOK = TRUE;
			}break;

		case 'F':{	//�ʑ��V�t�g�v�Z���s
			if (phsft){
				float *xyz;
				BYTE *rgb;
				bool dorect = true;
				int *rg_id = 0;         // �����W�O���b�h���_�̃s�N�Z���C���f�b�N�X�z��
				int num = phsft->exec(&xyz, &rgb, dorect, &rg_id);
				printf("detected num=%d\n", num);

				if (!rg_flg) {
					// �����W�O���b�h�̂Ƃ��̓m�C�Y�������Ȃ��iPLY�̒��_�̐�������Ȃ��Ȃ�j
					if (!__isnan(varea.xmin)) {
						noise_reduction(&num, xyz, rgb);
						printf("finish noise_del\n");
					}
				}

				char path[MAX_PATH];
				_snprintf_s(path, sizeof(path), _TRUNCATE, "%s%s", CAPT_DIR, "out.ply");
				savePly(path, num, xyz, rgb, rg_flg, IMGWIDTH, IMGHEIGHT, rg_id);
#ifdef PICKING
				HANDLE h = OpenEvent(EVENT_ALL_ACCESS, FALSE, PHSFT_DONE_EVENT);
				if (h){
					SetEvent(h);
					CloseHandle(h);
				}
#endif
			}
			else {
				*ipcOK = FALSE;
				fprintf(stderr, "error: phaseshift library not initialized.\n");
			}
		}break;

		case 'M':{	//�X�e���I���֌v�Z���s
			if (sgbm){
				float *xyz;
				BYTE *rgb;
				bool dorect = true;
				int *rg_id = 0;         // �����W�O���b�h���_�̃s�N�Z���C���f�b�N�X�z��
				int num = sgbm->exec(&xyz, &rgb, dorect, &rg_id);
				printf("detected num=%d\n", num);
				if (num){
					char path[MAX_PATH];
					_snprintf_s(path, sizeof(path), _TRUNCATE, "%s%s", CAPT_DIR, "out.ply");
					savePly(path, num, xyz, rgb, rg_flg, IMGWIDTH, IMGHEIGHT, rg_id);
				}
			}
			else{
				*ipcOK = FALSE;
				fprintf(stderr, "error: stereosgbm library not initialized.\n");
			}
		}break;
		}
		if (eventIpc && raise_event && dwEventNo==1){
			eventIpc->wake();
		}
	}
	Sleep(100);
	if (ipc){
		ipc->destroy();
	}
	delete eventIpc;
	if (ipc_proj)ipc_proj->destroy();
	//��n��
	camera->destroy();
	FreeLibrary(hCamera);
	if (phsft){
		phsft->destroy();
		FreeLibrary(hPhsft);
	}
	if (sgbm){
		sgbm->destroy();
		FreeLibrary(hSgbm);
	}

	return 0;
}

static UINT flg = 0;

//�摜�擾�R�[���o�b�N
int CALLBACK cb_recvimg(int camno, int index, int width, int height, void *mem)
{
	if (camno < 0 || 1 < camno)return 0;
	circles[camno].clear();
//	printf("%d-%d;%d,%d,%p\n", camno, index, width, height, mem);
	if (stdv_flg){
		BYTE *p = (PBYTE)mem;
		for (int y = 0; y < IMGHEIGHT; ++y){
			vector<int>hist(256, 0);
			int sum = 0;
			for (int x = 0; x < IMGWIDTH; ++x){
				sum += p[x];
				++hist[p[x]];
			}
			float N = IMGWIDTH;
			float u = sum / N;
			float v = 0.0f;
			for (int j = 0; j<hist.size(); ++j){
				v += (j - u)*(j - u) * hist[j];
			}
			v /= N;
			double s = sqrt(v);
			stdv[camno][y] = s;
			p += IMGWIDTH;
		}
	}
	InvalidateRect(hWnd[camno], NULL, TRUE);
	//
	if (live_flg){
		return 0;
	}
//	static Elapse e;
	char path[MAX_PATH];
#if 0
	sprintf_s(path, sizeof(path), "%d-%d.pgm",camno,index);
	saveImagePNM(path, (PBYTE)mem, width, height, 1);
#else
	if (calib_no < 0){
		//�L�����u�B�e�łȂ��ꍇ
		if ( (phsft && (0<=index && index<phsft->ptn_num())) ||		//�ʑ��V�t�g��0~12
			 (sgbm && index==0) ){									//�X�e���I���ւ̏ꍇ�͍ŏ���1���̂�
			if(camno==0 && index){
				printf("interval: %g msec\n",e.query());
				e.reset();
			}
			//�ЂƂ܂��R�s�[
			BYTE *camimg = camera_img[camno] + IMGSIZE*index;
			memcpy(camimg, mem, IMGSIZE);
		}
	}
	flg |= (1<<camno);
	if (flg == 3){
		BYTE *l = img[0];
		BYTE *r = img[1];
		*path = 0;
		if (calib_no < 0){
			//���ʂ̎B�e�A�ۑ��t���O�������Ă���Εۑ�
			if (save_flg) sprintf_s(path, sizeof(path), "%scapt%02d.pgm", CAPT_DIR,index);
		}
		else{
			//�L�����u�p�B�e
			sprintf_s(path, sizeof(path), "%scalib%02d.pgm", CALIB_DIR, calib_no);
		}
		if (*path){
			FILE *fp;
			errno_t err = fopen_s(&fp, path, "wb");
			if (!err){
				fprintf(fp, "P5\n%d %d\n255\n", IMGWIDTH * 2, IMGHEIGHT);
				for (int j = 0; j < IMGHEIGHT; ++j) {
					fwrite(l, 1, IMGWIDTH, fp);
					fwrite(r, 1, IMGWIDTH, fp);
					l += IMGWIDTH;
					r += IMGWIDTH;
				}
				fclose(fp);
			}
		}
		if (0 <= calib_no){
			if (eventIpc){
				eventIpc->wake();	//�L�����u�I��
			}
		}
		calib_no = -1;
		flg = 0;
	}
#endif
#ifdef PICKING
	static int phsft_bits = 0;
	static int sgbm_bits = 0;
	if (phsft_bits == 0 && phsft){
		for (int i = 0; i < phsft->ptn_num(); ++i) phsft_bits |= (1 << i);
	}
	if (sgbm_bits == 0){
		for (int i = 0; i < 1; ++i) sgbm_bits |= (1 << i);
	}
	recv_bit[camno] |= (1 << index);
	int bits = one_shot ? sgbm_bits : phsft_bits;
	if (recv_bit[0] == bits && recv_bit[0] == recv_bit[1]){
		printf("capture done(%d)\n", camera->capturedCount(0));
		camera->resetSequence();
		if (eventIpc) {
			eventIpc->wake();	//�I��
		}
		HANDLE h = OpenEvent(EVENT_ALL_ACCESS, FALSE, CAPT_DONE_EVENT);
		if (h){
			SetEvent(h);
			CloseHandle(h);
		}
	}
#endif
	if (timer_id) KillTimer(hWnd[0], TIMER_ID);
	timer_id = SetTimer(hWnd[0], TIMER_ID, TIMER_INTERVAL, timerProc);
	return 0;
}

#define CIRCLES CircleContour &c = (hwnd == hWnd[0] ? circles[0] : circles[1]); \
				for (auto i = c.begin(); i != c.end(); ++i){ \
					const int x = (int)(i->x*scale + 0.5f), y = (int)(i->y*scale + 0.5f); \
					SetPixel(memdc, x, y, RGB(255, 0, 0)); \
								}

#define STDV	if (stdv_flg){ \
					int max_y=0; float max_s=0.0f;\
					const auto &a = (hwnd == hWnd[0] ? stdv[0] : stdv[1]); \
					int j = 0; \
					for (auto i = a.begin(); i != a.end(); ++i, ++j){ \
						if (max_s < *i){max_s=*i;max_y=j;} \
						const int x = (int)((*i) * scale + 0.5f); \
						const int y = (int)(j * scale + 0.5f); \
						SetPixel(memdc, x, y, RGB(0, 255, 0)); \
					} \
					COLORREF rgb = RGB(255, 0, 0); \
					HPEN hPen = CreatePen(PS_SOLID, 1, rgb); \
					HPEN hOldPen = (HPEN)SelectObject(memdc, hPen); \
					const POINT p1 = { 0, (int)(max_y * scale) }; \
					const POINT p2 = { (int)((IMGWIDTH - 1) * scale), (int)(max_y * scale) }; \
					MoveToEx(memdc, p1.x, p1.y, NULL); \
					LineTo(memdc, p2.x, p2.y); \
					SelectObject(memdc, hOldPen); \
					DeleteObject(hPen); \
				}


//�E�C���h�E�v���V�W��
LRESULT WINAPI ConsoleDispWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	CS cs(&cs_window);
	int *hpos = (hwnd == hWnd[0] ? &Hpos[0] : &Hpos[1]);
	int *vpos = (hwnd == hWnd[0] ? &Vpos[0] : &Vpos[1]);
	float *scalep = (hwnd == hWnd[0] ? &scales[0] : &scales[1]);
	switch (msg)
	{
	case WM_CREATE:
		ShowWindow(hwnd, SW_SHOW);
		break;
	case WM_PAINT:{
		RECT r;
		SIZE s;
		GetClientRect(hwnd, &r);
		s.cx = r.right - r.left;
		s.cy = r.bottom - r.top;

		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);
		//if(!live_flg)FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_BACKGROUND + 1));
		{	//�摜�ȊO�̔w�i(�E)��h��Ԃ�
			int w = (int)(IMGWIDTH**scalep + 0.5f);
			if (w < s.cx) {
				RECT r = ps.rcPaint;
				r.left = w;
				FillRect(hdc, &r, (HBRUSH)(COLOR_BACKGROUND + 1));
			}
			//�摜�ȊO�̔w�i(��)��h��Ԃ�
			int h = (int)(IMGHEIGHT**scalep + 0.5f);
			if (h < s.cy) {
				RECT r = ps.rcPaint;
				r.top = h;
				FillRect(hdc, &r, (HBRUSH)(COLOR_BACKGROUND + 1));
			}
		}

		EndPaint(hwnd, &ps);

		BYTE *image = (hwnd == hWnd[0] ? img[0] : img[1]);
		BYTE *bitmap = (hwnd == hWnd[0] ? bmp[0] : bmp[1]);
		if (!image){
			break;
		}
		HDC hdcImg = GetDC(hwnd);
		HDC memdc = CreateCompatibleDC(hdcImg);
		HBITMAP hbmp = CreateCompatibleBitmap(hdcImg, s.cx, s.cy);
		SelectObject(memdc, hbmp);
		BYTE *image_small = (hwnd == hWnd[0] ? img_small[0] : img_small[1]);
#if 1
		float scale = 1.0f;
		int dx=0, dy = 0;
		if (GetWindowLong(hwnd, GWL_STYLE) & (WS_VSCROLL | WS_HSCROLL)){
			dispImageDC(memdc, image, IMGWIDTH, IMGHEIGHT, bitmap);
			//�~�֊s��`��
			CIRCLES
			//�W���΍��O���t
			STDV
			dx = *hpos;	//memdc�ɂ����̂ł���2�s�͕s�v
			dy = *vpos;
			BitBlt(hdcImg, *hpos, *vpos, IMGWIDTH, IMGHEIGHT, memdc, 0, 0, SRCCOPY);
		}
		else{
			float fw, fh;
			fw = (float)s.cx / (float)IMGWIDTH;
			fh = (float)s.cy / (float)IMGHEIGHT;
			float f = min(fw, fh);
			if (1.0f<f)f = 1.0f;
			scale = f;
			const int w = (int)(IMGWIDTH*f + 0.5f);
			const int h = (int)(IMGHEIGHT*f + 0.5f);
			resizeImage(image, IMGWIDTH, IMGHEIGHT, w, h, image_small);
			dispImageDC(memdc, image_small, w, h, bitmap);
			//�~�֊s��`��
			CIRCLES
			//�W���΍��O���t
			STDV
			BitBlt(hdcImg, ps.rcPaint.left, ps.rcPaint.top, ps.rcPaint.right - ps.rcPaint.left + 1, ps.rcPaint.bottom - ps.rcPaint.top + 1, memdc, ps.rcPaint.left, ps.rcPaint.top, SRCCOPY);
		}
		*scalep=scale;
#else
		resizeImageBL(image, IMGWIDTH, IMGHEIGHT, s.cx, s.cy, image_small);
		DispImageDC(memdc, image_small, s.cx, s.cy, bitmap);
		BitBlt(hdcImg, 0, 0, s.cx, s.cy, memdc, 0, 0, SRCCOPY);
#endif
		//StretchBlt(hdcImg, 0, 0, s.cx, s.cy, memdc, 0, 0, IMGWIDTH, IMGHEIGHT, SRCCOPY);
		////�~�֊s��`��
		//CircleContour &c = (hwnd == hWnd[0] ? circles[0] : circles[1]);
		//for (CircleContour::const_iterator i = c.begin(); i != c.end(); ++i){
		//	const int x = (int)(i->x*scale + 0.5f), y = (int)(i->y*scale + 0.5f);
		//	SetPixel(hdcImg, x+dx, y+dy, RGB(255, 0, 0));
		//}
		ReleaseDC(hwnd, hdcImg);
		DeleteDC(memdc);
		DeleteObject(hbmp);
		}break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_LBUTTONDBLCLK:{
		//break;
		LONG style = GetWindowLong(hwnd, GWL_STYLE);
		const LONG scbit = WS_VSCROLL | WS_HSCROLL;
		bool add = false;
		if (style & scbit) style &= ~scbit;
		else{
			add = true;
			style |= scbit;
		}
		SetWindowLong(hwnd, GWL_STYLE, style);
		SetWindowPos(hwnd, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
		if (add){
			RECT r; SIZE s;
			GetClientRect(hwnd, &r);
			s.cx = r.right - r.left + 1;
			s.cy = r.bottom - r.top + 1;
			SCROLLINFO si = { 0 };
			si.cbSize = sizeof(SCROLLINFO);
			si.fMask = SIF_PAGE | SIF_RANGE | SIF_DISABLENOSCROLL;
			si.nMin = 0;
			si.nMax = IMGWIDTH - s.cx;
			si.nPage = 1;
			SetScrollInfo(hwnd, SB_HORZ, &si, TRUE);
			si.nMax = IMGHEIGHT - s.cy;
			si.nPage = 1;
			SetScrollInfo(hwnd, SB_VERT, &si, TRUE);
		}
		}break;
	case WM_SIZE:
		if (GetWindowLong(hwnd, GWL_STYLE) & (WS_VSCROLL | WS_HSCROLL)){
			onSize(hwnd, IMGWIDTH, IMGHEIGHT, hpos, vpos);
		}
		break;
	case WM_VSCROLL:
		if (GetWindowLong(hwnd, GWL_STYLE) & WS_VSCROLL){
			onVScroll(hwnd, LOWORD(wParam),vpos);
		}
		break;
	case WM_HSCROLL:
		if (GetWindowLong(hwnd, GWL_STYLE) & WS_HSCROLL){
			onHScroll(hwnd, LOWORD(wParam), hpos);
		}
		break;
	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	return 0;
}

#define CONSOLEDISPCLASS         "ConsoleDispClass"

//�E�B���h�E�쐬
BOOL create_window(int camno)
{
	char title[32];
	sprintf_s(title, sizeof(title), "camera-%d", camno + 1);
	WNDCLASSEX wcx;
	HMODULE hInstance = GetModuleHandle(NULL);
	if (GetClassInfoEx(hInstance, CONSOLEDISPCLASS, &wcx) == 0)
	{
		// Fill in the window class structure with parameters that describe the main window. 
		wcx.cbSize = sizeof(wcx);          // size of structure 
		wcx.style = CS_HREDRAW | CS_NOCLOSE | CS_SAVEBITS | CS_VREDRAW | CS_DBLCLKS | WS_OVERLAPPED;
		wcx.lpfnWndProc = ConsoleDispWndProc;   // points to window procedure 
		wcx.cbClsExtra = 0;                    // no extra class memory 
		wcx.cbWndExtra = 0;                    // no extra window memory 
		wcx.hInstance = hInstance;            // handle to instance 
		wcx.hIcon = NULL;                 // no icon
		wcx.hCursor = NULL;                 // no cursor
		wcx.lpszMenuName = NULL;                 // name of menu resource 
		wcx.lpszClassName = CONSOLEDISPCLASS;     // name of window class 
		wcx.hIconSm = NULL;                 // small class icon 
		wcx.hbrBackground = NULL;

		// Register the window class. 
		atom = RegisterClassEx(&wcx);
	}
	if (atom != NULL)
	{
		int dx = 0;
		if (camno){
			RECT r;
			GetWindowRect(hWnd[0], &r);
			dx = r.right - r.left + 1;
		}
		// create our display window
		hWnd[camno] = CreateWindow(CONSOLEDISPCLASS,        // name of window class 
			title,  // title-bar string 
			WS_OVERLAPPEDWINDOW,      // top-level window 
			dx,//CW_USEDEFAULT,            // default horizontal position 
			0,//CW_USEDEFAULT,            // default vertical position 
			WWIDTH_INIT,             // default width 
			WHEIGHT_INIT,             // default height 
			(HWND)NULL,              // no owner window 
			(HMENU)NULL,             // use class menu 
			hInstance,                // handle to application instance 
			(LPVOID)NULL);            // no window-creation data 
		if (!hWnd[camno])
		{
			UnregisterClass(CONSOLEDISPCLASS, hInstance);
			atom = NULL;
		}
	}

	return (atom != NULL);
}

//Windows���[�v
UINT WINAPI window_loop(void *)
{
	for (int i = 0; i < CAMNUM; ++i){
		create_window(i);
		setClientSize(hWnd[i], WWIDTH_INIT, WHEIGHT_INIT);
	}
	//printf("hwnd %d %d\n", (int)hWnd[0], (int)hWnd[1]);
#ifdef PICKING
	create_pickwindow();
#endif

	MSG msg;
	while (0 != GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return (UINT)msg.wParam;
}


//���C�u���[�v
UINT WINAPI live_loop(void *)
{
	live_flg = TRUE;
	if (shmem)shmem->bLive = TRUE;
	const DWORD ms = 50;	//50�~���b��(�K��)
	live_end = false;
	do{
		{
			CS cs(&cs_camera);
			camera->capture();
		}
		Sleep(ms);
	} while (!live_end);
	Sleep(ms);
	live_flg = FALSE;
	if (shmem)shmem->bLive = FALSE;
	return 0;
}

//���C�u�I��
void stopLive()
{
	if (hThreadLive != INVALID_HANDLE_VALUE) {
		live_end = true;
		DWORD ret = WaitForSingleObject(hThreadLive, 500);
		if (ret == WAIT_TIMEOUT){
			printf("time out\n");
			if (!TerminateThread(hThreadLive, 0)){
				printf("faild to terminte live thread\n");
			}
		}
		CloseHandle(hThreadLive);
		hThreadLive = INVALID_HANDLE_VALUE;
	}
	camera->resetSequence();
}

//�J�����C���f�b�N�X�����Z�b�g����
//��A�̎B�e���I�������s��
//���̃A�v���ł̓^�C�}�[�ōs��
void CALLBACK timerProc(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	KillTimer(hWnd[0], TIMER_ID);
	memset(recv_bit, 0, sizeof(recv_bit));
	camera->resetSequence();
#if 0
	for (int i = 0; i < 2; ++i){
		char path[32];
		sprintf_s(path, sizeof(path), "camera-%d.pgm", i);
		saveImagePNM(path, camera_img[i], IMGWIDTH, IMGHEIGHT*13, 1);
	}
#endif
	com_proj.stop();
	printf("sequence was reset\n");
}

//YCAM3D���C�u���������[�h
//���������Ă��ŏ��Ɍ��������̂�Ԃ�
HMODULE loadYcamLibrary(pCreateIYCam3DInstance *pcreate_camera)
{
	char search[_MAX_PATH];
	char full[_MAX_PATH];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	GetModuleFileName(NULL, full, _MAX_PATH);
	_splitpath_s(full, drive, _MAX_DRIVE, dir, _MAX_DIR, NULL, 0, NULL, 0);
	_makepath_s(search, _MAX_PATH, drive, dir, NULL, NULL);
	strcat_s(search, "*.dll");

	HANDLE hFind;
	WIN32_FIND_DATA fd;
	hFind = FindFirstFile(search, &fd);
	if (hFind == INVALID_HANDLE_VALUE) {
		return 0;
	}
	HMODULE hCamera = 0;
	do {
		if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			continue;
		}
		hCamera = LoadLibrary(fd.cFileName);
		if (hCamera) {
			//�����ɃC���X�^���X�쐬�֐��|�C���^���擾
			pCreateIYCam3DInstance func= (pCreateIYCam3DInstance)GetProcAddress(hCamera, YCAM3DFUNCNAME);
			if (func) {
				printf("camera library found: [%s]\n", fd.cFileName);
				*pcreate_camera = func;
				break;
			}
			FreeLibrary(hCamera);
			hCamera = 0;
		}
		
	} while (FindNextFile(hFind, &fd));
	FindClose(hFind);
	return hCamera;
}



LRESULT CALLBACK PickProc(HWND hWindow, UINT msg, WPARAM wp, LPARAM lp);

BOOL create_pickwindow()
{
	HINSTANCE hInst = GetModuleHandle(NULL);
	LPCSTR pClassName = "PICK_WINDOW_CLASS";
	WNDCLASSEX wc;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = PickProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInst;
	wc.hIcon = NULL;
	wc.hIconSm = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = pClassName;

	if (!RegisterClassEx(&wc)) return FALSE;

	HWND hWindow = CreateWindow(pClassName, "PICK_WINDOW",
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInst, NULL);

	if (!hWindow){
		return FALSE;
	}
	//ShowWindow(hWindow, SW_SHOW);
	return TRUE;
}

LRESULT CALLBACK PickProc(HWND hWindow, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg) {
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_COPYDATA:{
		HANDLE h = OpenEvent(EVENT_ALL_ACCESS, FALSE, INPUT_EVENT);
		COPYDATASTRUCT *cds = (COPYDATASTRUCT*)lp;
		if (cds->dwData == 1){
			//		printf("(%d)%.*s\n", cds->dwData,cds->cbData,cds->lpData);
			printf("[PICK]%.*s", cds->cbData, cds->lpData);
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%.*s", cds->cbData, cds->lpData);
			SetEvent(h);
		}
		CloseHandle(h);
		}break;
	default:
		return DefWindowProc(hWindow, msg, wp, lp);
	}
	return 0;
}

UINT WINAPI gets_loop(void *arg)
{
	HANDLE h = OpenEvent(EVENT_ALL_ACCESS, FALSE, INPUT_EVENT);
	for (; fgets((char*)arg, 64, stdin); ){
		SetEvent(h);
	}
	CloseHandle(h);
	return 0;
}

void cb_func::operator()(CONST USHORT id, CONST TCHAR cmdType, LPCTSTR cmdName, CONST TCHAR dataType, LPBOOL pOK, PVAR pVar, LPINT pSize)
{
	ipcVar = pVar;
	ipcOK = pOK;

	*pOK = TRUE;
	//printf("### server cb function called ###\n");
	//printf(" id=%u\n", id);
	//printf(" cmdType=%c\n", cmdType);
	//printf(" cmdName=%s\n", cmdName);
	//printf(" dataType=%c\n", dataType);
	//printf(" ok=%d\n", *pOK);
	PVAR v = pVar;
	int len = *pSize;
	*key = '\0';
	switch (cmdType){
	case IpcCmdType_Set:	// Set
		//[�J����]
		if (!strcmp(cmdName, "N")){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "N%d\n", v->ival);
		}
		else if (!strcmp(cmdName, "E")){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "E%d\n", v->ival);
		}
		else if (!strcmp(cmdName, "G")){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "G%d\n", v->ival);
		}
		else if (!strcmp(cmdName, "L")){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "L%d\n", v->ival);
		}
		else if (!strcmp(cmdName, "T")){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "T%d\n", v->ival);
		}
		else if (!strcmp(cmdName, "C")){
			if (0 <= v->ival) _snprintf_s(key, sizeof(key), _TRUNCATE, "C%d\n", v->ival);
			else _snprintf_s(key, sizeof(key), _TRUNCATE, "C\n");
		}
		else if (!strcmp(cmdName, "V")){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "V%d\n", v->ival);
		}
		//[�L�����u���[�V����]
		else if (!strcmp(cmdName, "A")){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "A%d\n", v->ival);
		}
		//[�v���W�F�N�^�[]
		else if (!strcmp(cmdName, _T("TRIGMODE"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s\n", v->ival==TrigMode_HW ? "H":"S");
		}
		else if (!strcmp(cmdName, _T("P"))){
			if (v->ival){
				int a = v->ival;
				_snprintf_s(key, sizeof(key), _TRUNCATE, "%s%d.%d.%d.%d\n", "P", a & 0xff, (a >> 8) & 0xff, (a >> 16) & 0xff, (a >> 24) & 0xff);
			}
			else _snprintf_s(key, sizeof(key), _TRUNCATE, "%s\n", "P");
		}
		else if (!strcmp(cmdName, _T("B"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "B%d\n", v->ival);
		}
		else if (!strcmp(cmdName, _T("X"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "X%d\n", v->ival);
		}
		else {
			printf("$ invalid command name=%s\n", cmdName);
			*pOK = FALSE;
		}
		break;
	case IpcCmdType_Get:	// Get
		if (!strcmp(cmdName, "STATUS")){
			v->ival = init_status;
		}
		//[�J����]
		else if (!strcmp(cmdName, _T("E"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s\n", "E");
		}
		else if (!strcmp(cmdName, _T("G"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s\n", "G");
		}
		else if (!strcmp(cmdName, _T("TRIGMODE"))){
			v->ival = camera->triggerMode();
		}
		////[�v���W�F�N�^�[]
		else if (!strcmp(cmdName, _T("YPJADDR"))){
			v->ival = ypj_addr;
		}
		else if (!_tcscmp(cmdName, _T("B"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s\n", "B");
		}
		else if (!strcmp(cmdName, _T("R"))){ // �����W�O���b�hON/OFF�ؑց{���ݒl�擾
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s\n", "R");
		}
		else {
			*pOK = FALSE;
		}
		break;
	case IpcCmdType_Cmd:	// Command
		if (!strcmp(cmdName, _T("Q"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s", "Q\n");
		}
		//2017/06/06 ---------------------- start ------------------
		else if (!strcmp(cmdName, _T("J"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s", "J\n");
		}
		//2017/06/06 ----------------------  end  ------------------
		else if (!strcmp(cmdName, _T("K"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s", "K\n");
		}
		else if (!strcmp(cmdName, _T("O"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s", "O\n");
		}
		else if (!strcmp(cmdName, _T("F"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s", "F\n");
		}
		else if (!strcmp(cmdName, _T("M"))){
			_snprintf_s(key, sizeof(key), _TRUNCATE, "%s", "M\n");
		}
		else {
			printf("$ invalid command name=%s\n", cmdName);
			*pOK = FALSE;
		}
		break;
	default:
		*pOK = FALSE;
		printf("$ invalid command type=%d\n", cmdType);
		break;
	}
	if (*key){
		printf(key);
		SetEvent(hEventInputIpc);	//IPC�L�[����
		eventIpc->wait();	//�I���܂ő҂�
		eventIpc->reset();
	}
}
